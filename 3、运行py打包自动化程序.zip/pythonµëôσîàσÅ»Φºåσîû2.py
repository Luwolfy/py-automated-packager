import tkinter as tk
from tkinter import filedialog, messagebox
import subprocess
import sys
import os

def select_python_script():
    file_path = filedialog.askopenfilename(
        title="选择Python脚本",
        filetypes=[("Python Files", "*.py")]
    )
    if file_path:
        entry_script.delete(0, tk.END)
        entry_script.insert(0, file_path)

def select_destination_folder():
    folder_path = filedialog.askdirectory(title="选择导出文件夹")
    if folder_path:
        entry_folder.delete(0, tk.END)
        entry_folder.insert(0, folder_path)

def package_script():
    python_script = entry_script.get()
    destination_folder = entry_folder.get()
    
    # 确保用户选择了Python脚本和目标文件夹
    if not python_script or not os.path.isfile(python_script):
        messagebox.showerror("错误", "请选择一个存在的Python脚本文件")
        return
    if not destination_folder or not os.path.isdir(destination_folder):
        messagebox.showerror("错误", "请选择一个有效的文件夹")
        return
    
    try:
        # 获取脚本所在目录
        script_dir = os.path.dirname(python_script)
        
        # 更改工作目录到脚本所在目录
        os.chdir(script_dir)
        
        # 构造 PyInstaller 命令
        pyinstaller_cmd = [
            sys.executable, '-m', 'PyInstaller', '--onefile',
            '--distpath', destination_folder, os.path.basename(python_script)
        ]
        
        # 执行 PyInstaller 命令
        subprocess.check_call(pyinstaller_cmd)
        
        # 检查生成的exe文件是否存在
        base_script_name = os.path.basename(python_script).split('.')[0]
        exe_file_path = os.path.join(destination_folder, base_script_name + '.exe')
        if os.path.isfile(exe_file_path):
            messagebox.showinfo("打包成功", f"可执行文件已生成在：\n{exe_file_path}")
        else:
            raise FileNotFoundError(f"打包过程中没有生成可执行文件在：{destination_folder}")
    
    except subprocess.CalledProcessError as e:
        messagebox.showerror("打包失败", f"PyInstaller 打包过程中发生错误: {e}")
    except Exception as e:
        messagebox.showerror("打包失败", f"打包过程中发生未知错误: {e}")

# 创建主窗口
root = tk.Tk()
root.title("Python脚本打包工具")

# 创建界面元素（省略了之前的代码以节省空间

# 创建界面元素
label_script = tk.Label(root, text="Python脚本路径:")
label_script.pack()

entry_script = tk.Entry(root, width=50)
entry_script.pack()

button_script = tk.Button(root, text="浏览", command=select_python_script)
button_script.pack()

label_folder = tk.Label(root, text="导出文件夹路径:")
label_folder.pack()

entry_folder = tk.Entry(root, width=50)
entry_folder.pack()

button_folder = tk.Button(root, text="浏览", command=select_destination_folder)
button_folder.pack()

button_package = tk.Button(root, text="打包", command=package_script)
button_package.pack()

# 运行主循环
root.mainloop()